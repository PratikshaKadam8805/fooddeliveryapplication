import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcom-component',
  templateUrl: './welcom-component.component.html',
  styleUrls: ['./welcom-component.component.css']
})
export class WelcomComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
